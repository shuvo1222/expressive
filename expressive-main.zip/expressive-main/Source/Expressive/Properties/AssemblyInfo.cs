﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("9571bbbb-3f9b-4f46-8a5c-efd5ec13e5b1")]

[assembly: InternalsVisibleTo("Expressive.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100495afe3ea98fd0459102e8a5201f106f053d747699b49c82f4c08ae2617ffd1ab133db21560cc1d1721e7f193c472fbbe6d576b4a7690a897083fa55ae41c3d105f36c2063699095eba800c78448af0796cfd6e887308a2bf5a745aeb595450b5aa96c9f5d511d61d9f5c67faa6aa8e56bb6ddd641c38abcec30b714e89f2bbc")]
